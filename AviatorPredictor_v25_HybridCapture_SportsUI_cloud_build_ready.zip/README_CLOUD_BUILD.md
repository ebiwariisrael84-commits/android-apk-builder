# Aviator Predictor v25 cloud build

This package contains the Android project at the ZIP root and a GitHub Actions workflow in `.github/workflows/aviator-v25-build.yml`. Upload/commit the extracted contents to the root of a GitHub repository. Push to `main` or run the workflow manually, then download the APK artifact from the completed Actions run.

This archive contains source and build configuration, not a prebuilt APK. Real-device testing is required to verify hybrid iframe capture, OCR quality, and authenticated Supabase upload.
