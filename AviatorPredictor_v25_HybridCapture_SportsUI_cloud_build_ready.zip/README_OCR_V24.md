# Aviator Predictor v25 — rendered-frame OCR, cloud sync, esports UI

## Changes in v25
- Redesigned the in-app interface with a midnight esports/sports-broadcast look, teal/lime accents, gradient hero and analysis cards, improved labels and a live history chart.
- Replaced the primary rendered-frame capture path on Android 8+ with `PixelCopy` of the visible game WebView area. This is more appropriate for GPU-composited WebView/iframe content than relying only on `WebView.draw(Canvas)`. Android 7.x retains a fallback.
- OCR continues to use bundled ML Kit Latin recognition, groups text lines by vertical position, and only considers a history row when at least three plausible multipliers and an x/× marker are present. It separately looks for a single prominent multiplier to refresh the live signal, so canvas-based games do not depend solely on DOM text.
- Added stable device ID, per-session UUID, persistent offline queue, anonymous Supabase Auth session attempt, JWT refresh, batch uploads (up to 100 observations), duplicate-event handling, and queue retention during failed uploads.
- Sends completed-row observations from OCR and DOM extraction to the existing `aviator-ingest` Edge Function in the recommended Supabase project. The backend keeps these readings in `pending` validation state; they are not automatically treated as verified round outcomes.
- Stops the frame-capture and UI-watchdog loops when the activity is destroyed, and avoids overwriting newly queued observations when a batch upload completes.

## Cloud details
Project URL: `https://bikjzdjrtgurraqpwfbk.supabase.co`
Function: `aviator-ingest`
The embedded key is the public/legacy anon API key, not the service-role secret. The service-role key remains only in Supabase Edge Function secrets. Anonymous sign-in must be enabled for this app-side sign-in flow; if it is disabled, the app retains its observations in the local queue and displays the error in its diagnostics.

## Build
Requires JDK 17, Gradle 8.9, Android SDK platform 35 and build-tools 35.0.0. Run `./build_ocr_apk.sh` or use the provided GitHub Actions workflow.

## Validation status / limitations
Source checks found no Java syntax errors, and the project ZIP can be integrity-checked. This environment has no Android SDK/Gradle installation, so this revision has **not** been compiled into an APK here. PixelCopy/OCR behavior, game-site compatibility, anonymous Auth availability, and a real ingestion response still need on-device runtime verification. Keep the game WebView visible while scanning. The URL crawler is a raw HTTP/HTML parser and may not see figures rendered only by JavaScript; the visible WebView OCR/DOM path is intended to cover that case.

Crash-game outcomes are random. The app's output is statistical analysis, not a reliable guarantee of the next round.


Version 25 adds hybrid capture: PixelCopy as primary, periodic WebView.draw cross-check, immediate draw fallback when PixelCopy fails, plus existing DOM/iframe extraction. It also refreshes the UI with a green/lime, red, yellow, and charcoal sports-game palette and an original aircraft-inspired launcher icon. Real-device OCR and backend upload testing are still required.
