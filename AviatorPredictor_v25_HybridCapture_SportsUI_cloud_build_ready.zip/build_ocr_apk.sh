#!/bin/sh
set -eu
cd "$(dirname "$0")"
GRADLE_VERSION=8.9
if command -v gradle >/dev/null 2>&1; then
  GRADLE=gradle
else
  CACHE="${XDG_CACHE_HOME:-$HOME/.cache}/aviator-ai-build"
  DIST="$CACHE/gradle-$GRADLE_VERSION"
  if [ ! -x "$DIST/bin/gradle" ]; then
    mkdir -p "$CACHE"
    ARCHIVE="$CACHE/gradle-$GRADLE_VERSION-bin.zip"
    URL="https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"
    echo "Gradle not installed; downloading Gradle $GRADLE_VERSION..."
    if command -v curl >/dev/null 2>&1; then curl -fL --retry 2 "$URL" -o "$ARCHIVE"; \
    elif command -v wget >/dev/null 2>&1; then wget -O "$ARCHIVE" "$URL"; \
    else echo 'Install curl or wget to download Gradle.' >&2; exit 2; fi
    command -v unzip >/dev/null 2>&1 || { echo 'Install unzip to extract Gradle.' >&2; exit 2; }
    unzip -q -o "$ARCHIVE" -d "$CACHE"
  fi
  GRADLE="$DIST/bin/gradle"
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -n "${ANDROID_SDK_ROOT:-}" ]; then export ANDROID_HOME="$ANDROID_SDK_ROOT"; fi
if [ -z "${ANDROID_HOME:-}" ]; then
  for candidate in "$HOME/Android/Sdk" "$HOME/android-sdk" "${PREFIX:-/nonexistent}/opt/android-sdk"; do
    if [ -d "$candidate/platforms" ]; then export ANDROID_HOME="$candidate"; break; fi
  done
fi
if [ -z "${ANDROID_HOME:-}" ] || [ ! -d "$ANDROID_HOME/platforms/android-35" ]; then
  echo 'Android SDK platform 35 not found. Install Android SDK platform 35 and set ANDROID_HOME.' >&2
  exit 2
fi
"$GRADLE" --no-daemon --stacktrace assembleDebug
APK='build/outputs/apk/debug/app-debug.apk'
[ -f "$APK" ] || { echo "Build finished but APK not found: $APK" >&2; exit 3; }
mkdir -p dist
cp "$APK" dist/AviatorAI_LiveAnalyzer_v25_PixelCopy_OCR_Cloud.apk
printf 'APK: %s\n' "$PWD/dist/AviatorAI_LiveAnalyzer_v25_PixelCopy_OCR_Cloud.apk"
