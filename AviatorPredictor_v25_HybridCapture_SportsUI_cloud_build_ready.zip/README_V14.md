Aviator AI Live Analyzer v14 – Capture Integrity Fix

This build addresses the stale 1.44x UI and source/capture ambiguity. It distinguishes the main rendered WebView page, discovered iframe sources, network/public URL sources, and changing live DOM candidates. It tracks candidate values over time and only accepts a rendered candidate after repeated changes, rather than treating a static historical 1.44x as a new round. A watchdog explicitly changes the dashboard to NO FRESH LIVE READING when no fresh candidate arrives.

The network/public URL parser remains best-effort and is not treated as proof of a live game stream. The app does not bypass authentication, anti-bot controls, private APIs, or protected streams. Statistical estimates remain uncertain and are not guaranteed predictions.
