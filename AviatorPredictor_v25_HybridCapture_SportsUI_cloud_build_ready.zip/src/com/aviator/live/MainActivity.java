package com.aviator.live;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.view.PixelCopy;
import android.widget.*;
import android.webkit.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.security.MessageDigest;
import android.net.Uri;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

public class MainActivity extends Activity {
    LinearLayout root, historyBox, statsBox;
    TextView status, latest, prediction, confidence, accuracy, aiState, intelligence, dataQuality, audit, browserStatus, dashboard, calibration, anomaly, replayStatus, insightBox, sessionHealth, simulationBox, fairnessBox;
    EditText endpoint, manual;
    CheckBox live;
    ChartView chart;
    WebView browser, frameBrowser;
    TextView sourceMatrix;
    TextView frameScanStatus;
    TextView cloudBadge;
    volatile boolean frameScanEnabled=true;
    long capturedFrames=0;
    long changedFrames=0;
    long lastFrameHash=0;
    long lastFrameCaptureMs=0;
    final Handler mainHandler=new Handler(Looper.getMainLooper());
    volatile boolean activityDestroyed=false;
    Runnable frameCaptureTask;
    Runnable watchdogTask;
    TextRecognizer ocrRecognizer;
    volatile boolean ocrBusy=false;
    long lastOcrStartMs=0;
    long ocrFrames=0;
    long ocrRowsFound=0;
    String lastOcrText="Waiting for first OCR result";
    String lastOcrDecision="No OCR decision yet";
    String lastOcrLiveDecision="No prominent live multiplier detected yet";
    final HashMap<String,Double> candidateLast = new HashMap<String,Double>();
    final HashMap<String,Integer> candidateChanges = new HashMap<String,Integer>();
    ArrayList<Double> lastHistoryRow = new ArrayList<Double>();
    String historyDiagnostic = "history row not detected yet";
    long historyRowsRead = 0;
    int captureSeq=0;
    int renderCaptureSeq=0;
    int iframeDiscovered=0;
    int iframeConnected=0;
    ScheduledExecutorService scheduler;
    final ArrayList<Double> rounds = new ArrayList<Double>();
    final Object lock = new Object();
    android.content.SharedPreferences prefs;
    OnlineModel model;
    String lastFingerprint="";
    String lastSource="";
    long lastFetchMs=0, lastLatencyMs=0, gapCount=0;
    int pollMs=500;
    volatile boolean fetchInFlight=false;
    int newDataCount=0;
    long observationCount=0;
    long unchangedCaptureCount=0;
    long sessionStartedMs=System.currentTimeMillis();
    long lastFreshRoundMs=0;
    long lastLiveChangeMs=0;
    String lastRoundValue="";
    double liveMultiplier=0.0;
    double previousLiveMultiplier=0.0;
    double lastCompletedRound=0.0;
    String discoveredFrameUrl="";
    String lastCrawlerValue="";
    int appSchema=25;
    int simulationCount=0;
    long lastAnalysisMs=0;
    boolean replayMode=false;
    boolean rendererRestarting=false;
    volatile boolean iframeArmed=false;
    volatile boolean aiBusy=false;
    String deviceId="", sessionId="";
    volatile boolean cloudSyncInFlight=false;
    volatile String cloudStatus="Cloud sync: queued / not yet verified";
    String cloudAccessToken="", cloudRefreshToken="";
    static final String SUPABASE_URL="https://bikjzdjrtgurraqpwfbk.supabase.co";
    static final String SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJpa2p6ZGpydGd1cnJhcXB3ZmJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE3MTExODEsImV4cCI6MjEwNzI4NzE4MX0.3109WzWwC2x6nsNgfyyNSVyxRoh5TqzCq0XKTdoNONo";
    volatile boolean predictionReady=false;
    long lastAiCompletedMs=0;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView text(String s,float sp,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setPadding(dp(4),dp(4),dp(4),dp(4)); return t; }
    TextView label(String s){ TextView t=text(s,11,Color.rgb(185,255,55)); t.setTypeface(null,1); t.setLetterSpacing(0.08f); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(11); b.setTypeface(null,1); b.setTextColor(Color.rgb(8,12,8)); b.setAllCaps(false); b.setLetterSpacing(0.02f); b.setBackground(round(Color.rgb(185,255,55),dp(12))); if(android.os.Build.VERSION.SDK_INT>=21)b.setElevation(dp(2)); return b; }
    GradientDrawable round(int c,int r){ GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(r); return g; }
    LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(15),dp(14),dp(15),dp(14)); GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(22,29,27),Color.rgb(9,13,14)}); bg.setCornerRadius(dp(18)); bg.setStroke(dp(1),Color.rgb(60,83,49)); l.setBackground(bg); if(android.os.Build.VERSION.SDK_INT>=21)l.setElevation(dp(2)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(12)); l.setLayoutParams(p); return l; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(5,8,10)); getWindow().setNavigationBarColor(Color.rgb(5,8,10)); if(android.os.Build.VERSION.SDK_INT>=21)getWindow().getDecorView().setSystemUiVisibility(0); prefs=getSharedPreferences("aviator_ai",MODE_PRIVATE); int oldSchema=prefs.getInt("app_schema",0); if(oldSchema!=appSchema){ prefs.edit().putInt("app_schema",appSchema).apply(); } model=new OnlineModel(prefs); deviceId=prefs.getString("cloud_device_id",""); if(deviceId.length()==0){deviceId=UUID.randomUUID().toString();prefs.edit().putString("cloud_device_id",deviceId).apply();} sessionId=UUID.randomUUID().toString(); cloudAccessToken=prefs.getString("cloud_access_token",""); cloudRefreshToken=prefs.getString("cloud_refresh_token",""); try{ocrRecognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);}catch(Throwable ocrInitError){Log.e("AviatorAI-OCR","OCR init failed",ocrInitError);} observationCount=prefs.getLong("observation_count",0); unchangedCaptureCount=prefs.getLong("unchanged_capture_count",0); gapCount=prefs.getLong("gap_count",0); sessionStartedMs=System.currentTimeMillis(); loadRounds(); buildUi(); refreshUi(); startUiWatchdog(); scheduleFrameCapture(1200); syncCloudQueue(); }

    void buildUi(){
        ScrollView sv=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(12),dp(12),dp(12),dp(20)); root.setBackgroundColor(Color.rgb(5,8,10)); sv.addView(root); setContentView(sv);

        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); head.setPadding(dp(4),dp(6),dp(4),dp(16));
        TextView logo=text("✈",29,Color.WHITE); logo.setGravity(Gravity.CENTER); logo.setTypeface(null,1); GradientDrawable logoBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(226,35,35),Color.rgb(255,193,7)}); logoBg.setCornerRadius(dp(16)); logoBg.setStroke(dp(1),Color.rgb(255,224,120)); logo.setBackground(logoBg); if(android.os.Build.VERSION.SDK_INT>=21)logo.setElevation(dp(5)); head.addView(logo,new LinearLayout.LayoutParams(dp(56),dp(56)));
        LinearLayout ht=new LinearLayout(this); ht.setOrientation(LinearLayout.VERTICAL); ht.setPadding(dp(11),0,0,0);
        TextView title=text("AVIATOR PREDICTOR",20,Color.WHITE); title.setTypeface(null,1); title.setLetterSpacing(0.025f); ht.addView(title);
        ht.addView(text("AI ANALYTICS  /  ESPORTS MODE",9,Color.rgb(193,201,180))); head.addView(ht,new LinearLayout.LayoutParams(0,-2,1));
        TextView liveBadge=text("● LIVE SCAN",9,Color.rgb(185,255,55)); liveBadge.setTypeface(null,1); liveBadge.setPadding(dp(10),dp(7),dp(10),dp(7)); GradientDrawable badgeBg=round(Color.rgb(27,55,20),dp(18)); badgeBg.setStroke(dp(1),Color.rgb(113,170,45)); liveBadge.setBackground(badgeBg); head.addView(liveBadge);
        root.addView(head);
        LinearLayout heroStrip=new LinearLayout(this); heroStrip.setOrientation(LinearLayout.VERTICAL); heroStrip.setPadding(dp(16),dp(14),dp(16),dp(14)); GradientDrawable heroBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(17,67,35),Color.rgb(12,23,18),Color.rgb(91,23,20)}); heroBg.setCornerRadius(dp(18)); heroBg.setStroke(dp(1),Color.rgb(113,139,51)); heroStrip.setBackground(heroBg);
        TextView heroKicker=text("MATCHDAY FLIGHT DECK  •  LIVE SIGNALS",10,Color.rgb(255,202,40)); heroKicker.setTypeface(null,1); heroStrip.addView(heroKicker);
        TextView heroTitle=text("Track every round. Verify every signal.",18,Color.WHITE); heroTitle.setTypeface(null,1); heroTitle.setPadding(0,dp(6),0,dp(3)); heroStrip.addView(heroTitle);
        TextView heroSub=text("HYBRID PIXEL CAPTURE + OCR + PAGE DATA  •  NO GUARANTEED OUTCOMES",9,Color.rgb(204,208,193)); heroStrip.addView(heroSub); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.setMargins(0,0,0,dp(12)); heroStrip.setLayoutParams(hp); root.addView(heroStrip);

        LinearLayout source=card(); source.addView(label("LIVE FEED  /  CAPTURE CONTROL"));
        endpoint=new EditText(this); endpoint.setSingleLine(true); endpoint.setText("https://www.sportybet.com/ng/m/games/spribe/aviator"); endpoint.setTextColor(Color.rgb(244,247,231)); endpoint.setHintTextColor(Color.rgb(142,155,138)); endpoint.setTextSize(12); endpoint.setSingleLine(true); endpoint.setBackground(round(Color.rgb(8,12,13),dp(12))); endpoint.setPadding(dp(10),dp(8),dp(10),dp(8)); source.addView(endpoint);
        LinearLayout sb=new LinearLayout(this); Button open=button("OPEN"); Button fetch=button("CRAWL URL"); Button reconnect=button("RECONNECT"); sb.addView(open,new LinearLayout.LayoutParams(0,dp(46),1)); sb.addView(fetch,new LinearLayout.LayoutParams(0,dp(46),1)); sb.addView(reconnect,new LinearLayout.LayoutParams(0,dp(46),1)); source.addView(sb);
        status=text("Ready — open the Aviator page",11,Color.rgb(156,163,175)); source.addView(status);
        browserStatus=text("WebView: waiting",11,Color.rgb(156,163,175)); source.addView(browserStatus);
        sourceMatrix=text("Two sources: URL crawler OFF • iframe OFF",11,Color.rgb(156,163,175)); source.addView(sourceMatrix); cloudBadge=text(cloudStatus,10,Color.rgb(193,201,180)); source.addView(cloudBadge);
        LinearLayout frameTools=new LinearLayout(this); Button frameToggle=button("PAUSE FRAME SCAN"); Button frameShot=button("CAPTURE FRAME"); frameTools.addView(frameToggle,new LinearLayout.LayoutParams(0,dp(44),1)); frameTools.addView(frameShot,new LinearLayout.LayoutParams(0,dp(44),1)); source.addView(frameTools);
        frameScanStatus=text("Visual frame scan: starting • OCR initializing",10,Color.rgb(156,163,175)); source.addView(frameScanStatus);
        frameToggle.setOnClickListener(new View.OnClickListener(){public void onClick(View v){frameScanEnabled=!frameScanEnabled;frameToggle.setText(frameScanEnabled?"PAUSE FRAME SCAN":"START FRAME SCAN");frameScanStatus.setText(frameScanEnabled?"Hybrid capture active • PixelCopy + WebView.draw + DOM":"Hybrid capture paused");if(frameScanEnabled) scheduleFrameCapture(150);}});
        frameShot.setOnClickListener(new View.OnClickListener(){public void onClick(View v){captureRenderedFrame(true);}});
        open.setOnClickListener(new View.OnClickListener(){public void onClick(View v){openBrowser(endpoint.getText().toString().trim());}});
        fetch.setOnClickListener(new View.OnClickListener(){public void onClick(View v){fetchLive();}});
        reconnect.setOnClickListener(new View.OnClickListener(){public void onClick(View v){reconnectCapture();}});

        LinearLayout game=card(); game.addView(label("AVIATOR ARENA  /  LIVE GAME"));
        browser=new WebView(this); WebSettings ws=browser.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setDatabaseEnabled(true); ws.setLoadsImagesAutomatically(true); ws.setMediaPlaybackRequiresUserGesture(false); if(android.os.Build.VERSION.SDK_INT>=21)ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE); browser.setBackgroundColor(Color.rgb(8,12,13)); android.webkit.CookieManager.getInstance().setAcceptCookie(true); android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(browser,true);
        browser.setWebChromeClient(debugChrome("MAIN")); browser.setWebViewClient(debugClient("MAIN"));
        browser.addJavascriptInterface(new Object(){ @JavascriptInterface public void capture(String payload){ processBrowserPayload(payload); }},"AviatorBridge");
        game.addView(browser,new LinearLayout.LayoutParams(-1,dp(300))); root.addView(game); root.addView(source);
        frameBrowser=new WebView(this); frameBrowser.setVisibility(View.GONE); frameBrowser.setAlpha(0f); WebSettings fws=frameBrowser.getSettings(); fws.setJavaScriptEnabled(true); fws.setDomStorageEnabled(true); fws.setDatabaseEnabled(true); fws.setLoadsImagesAutomatically(true); fws.setMediaPlaybackRequiresUserGesture(false); android.webkit.CookieManager.getInstance().setAcceptCookie(true); android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(frameBrowser,true); frameBrowser.setWebChromeClient(debugChrome("FRAME")); frameBrowser.setWebViewClient(debugClient("FRAME")); frameBrowser.addJavascriptInterface(new Object(){ @JavascriptInterface public void capture(String payload){ processBrowserPayload("FRAME\n"+payload); }},"AviatorBridge"); root.addView(frameBrowser,new LinearLayout.LayoutParams(1,1));

        LinearLayout result=card(); GradientDrawable resultBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(22,76,36),Color.rgb(12,22,17),Color.rgb(82,23,20)}); resultBg.setCornerRadius(dp(20)); resultBg.setStroke(dp(1),Color.rgb(185,255,55)); result.setBackground(resultBg); result.addView(label("LIVE ANALYSIS  /  PRIMARY SIGNAL"));
        latest=text("WAITING FOR LIVE FIGURES",25,Color.rgb(185,255,55)); latest.setGravity(Gravity.CENTER); result.addView(latest,new LinearLayout.LayoutParams(-1,dp(64)));
        prediction=text("AI is waiting for a live reading",15,Color.WHITE); prediction.setGravity(Gravity.CENTER); result.addView(prediction);
        confidence=text("—",12,Color.rgb(156,163,175)); confidence.setGravity(Gravity.CENTER); result.addView(confidence);
        intelligence=text("Model: waiting",11,Color.rgb(156,163,175)); intelligence.setGravity(Gravity.CENTER); result.addView(intelligence);
        root.addView(result);

        LinearLayout modelCard=card(); modelCard.addView(label("AI MODEL"));
        aiState=text("Waiting for completed rounds",13,Color.WHITE); modelCard.addView(aiState);
        accuracy=text("Learning: —",11,Color.rgb(156,163,175)); modelCard.addView(accuracy);
        dashboard=text("Calculation: —",11,Color.rgb(156,163,175)); modelCard.addView(dashboard);
        anomaly=text("Analysis: —",11,Color.rgb(156,163,175)); modelCard.addView(anomaly);
        audit=text("Prediction state: hidden until the model finishes",11,Color.rgb(156,163,175)); modelCard.addView(audit);
        chart=new ChartView(this); LinearLayout.LayoutParams chartParams=new LinearLayout.LayoutParams(-1,dp(132)); chartParams.setMargins(0,dp(10),0,dp(6)); modelCard.addView(chart,chartParams);
        LinearLayout mb=new LinearLayout(this); Button replay=button("BACKTEST"); Button reset=button("RESET LEARNING"); mb.addView(replay,new LinearLayout.LayoutParams(0,dp(46),1)); mb.addView(reset,new LinearLayout.LayoutParams(0,dp(46),1)); modelCard.addView(mb);
        replayStatus=text("Backtest: idle",11,Color.rgb(156,163,175)); modelCard.addView(replayStatus); root.addView(modelCard);
        replay.setOnClickListener(new View.OnClickListener(){public void onClick(View v){runReplay();}});
        reset.setOnClickListener(new View.OnClickListener(){public void onClick(View v){model.reset();predictionReady=false;status.setText("Learning model reset");refreshUi();}});

        LinearLayout stats=card(); stats.addView(label("SESSION"));
        insightBox=text("Waiting for completed rounds",11,Color.WHITE); stats.addView(insightBox);
        sessionHealth=text("Source health: —",11,Color.rgb(156,163,175)); stats.addView(sessionHealth);
        dataQuality=text("Data quality: waiting",11,Color.rgb(156,163,175)); stats.addView(dataQuality);
        Button clear=button("CLEAR HISTORY"); stats.addView(clear,new LinearLayout.LayoutParams(-1,dp(46))); root.addView(stats);
        clear.setOnClickListener(new View.OnClickListener(){public void onClick(View v){ synchronized(lock){rounds.clear();} prefs.edit().remove("rounds").apply(); model.reset(); predictionReady=false; lastFreshRoundMs=0; liveMultiplier=0; lastRoundValue=""; observationCount=0; unchangedCaptureCount=0; gapCount=0; refreshUi(); }});

        LinearLayout history=card(); history.addView(label("RECENT ROUNDS")); historyBox=new LinearLayout(this); historyBox.setOrientation(LinearLayout.VERTICAL); history.addView(historyBox); root.addView(history);
        TextView note=text("HYBRID ENGINE: DOM/page data runs alongside visible-frame capture. PixelCopy is primary on supported Android versions; WebView.draw is sampled as a fallback and cross-check. Readings must be validated before they influence analysis. Statistical analysis only — no guaranteed outcomes.",10,Color.rgb(142,155,138)); root.addView(note);
    }

    // Hybrid capture: DOM extraction runs independently; PixelCopy is the primary rendered-pixel
    // path on Android 8+, while WebView.draw is sampled every third cycle and is also the immediate
    // fallback when PixelCopy fails. The two pixel paths therefore supplement rather than replace
    // one another. A successful copy alone does not prove OCR correctness; diagnostics show method.
    void scheduleFrameCapture(long delay){
        if(activityDestroyed)return;
        if(frameCaptureTask!=null)mainHandler.removeCallbacks(frameCaptureTask);
        frameCaptureTask=new Runnable(){public void run(){
            if(activityDestroyed)return;
            if(frameScanEnabled)captureRenderedFrame(false);
            scheduleFrameCapture(frameScanEnabled?850:1500);
        }};
        mainHandler.postDelayed(frameCaptureTask,delay);
    }
    void captureRenderedFrame(final boolean manual){
        if(activityDestroyed || browser==null || browser.getWidth()<2 || browser.getHeight()<2 || !browser.isShown()){
            if(frameScanStatus!=null)frameScanStatus.setText("Frame scan waiting • open Aviator and keep the game visible on screen");
            return;
        }
        try{
            renderCaptureSeq++;
            // Keep PixelCopy as the main source, but periodically sample the WebView drawing path
            // so devices/surfaces where one route misses content still have a second chance.
            if(android.os.Build.VERSION.SDK_INT<26 || (!manual && renderCaptureSeq%3==0)){
                captureRenderedFrameFallback(manual, android.os.Build.VERSION.SDK_INT<26 ? "PixelCopy unavailable on this Android version" : "hybrid draw cross-check");
                return;
            }
            if(android.os.Build.VERSION.SDK_INT>=26){
                int[] loc=new int[2]; browser.getLocationInWindow(loc);
                View decor=getWindow().getDecorView();
                int winW=decor.getWidth(),winH=decor.getHeight();
                int left=Math.max(0,loc[0]), top=Math.max(0,loc[1]);
                int right=Math.min(winW,loc[0]+browser.getWidth());
                int bottom=Math.min(winH,loc[1]+browser.getHeight());
                if(right<=left||bottom<=top){if(frameScanStatus!=null)frameScanStatus.setText("Frame scan waiting • game view is outside the visible window");return;}
                final Rect rect=new Rect(left,top,right,bottom);
                final Bitmap bitmap=Bitmap.createBitmap(rect.width(),rect.height(),Bitmap.Config.ARGB_8888);
                PixelCopy.request(getWindow(),rect,bitmap,new PixelCopy.OnPixelCopyFinishedListener(){
                    @Override public void onPixelCopyFinished(int copyResult){
                        if(activityDestroyed){if(!bitmap.isRecycled())bitmap.recycle();return;}
                        if(copyResult==PixelCopy.SUCCESS){processCapturedBitmap(bitmap,manual,"PixelCopy");}
                        else {if(!bitmap.isRecycled())bitmap.recycle();captureRenderedFrameFallback(manual,"PixelCopy code "+copyResult);}
                    }
                },mainHandler);
            }else captureRenderedFrameFallback(manual,"legacy renderer");
        }catch(Throwable e){captureRenderedFrameFallback(manual,"capture fallback: "+shortErr(e));}
    }
    void captureRenderedFrameFallback(boolean manual,String reason){
        try{
            if(activityDestroyed||browser==null||browser.getWidth()<2||browser.getHeight()<2)return;
            int w=Math.min(960,browser.getWidth());
            int h=Math.max(1,(int)(browser.getHeight()*(w/(float)browser.getWidth())));
            Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(bmp);
            c.scale(w/(float)browser.getWidth(),h/(float)browser.getHeight()); browser.draw(c);
            processCapturedBitmap(bmp,manual,"WebView.draw / "+reason);
            if(frameScanStatus!=null)frameScanStatus.setText("HYBRID CAPTURE • WebView.draw • "+reason+" • frames "+capturedFrames+" • OCR "+ocrFrames);
        }catch(Throwable e){if(frameScanStatus!=null)frameScanStatus.setText("Frame scan error: "+shortErr(e));}
    }
    void processCapturedBitmap(final Bitmap bmp,boolean manual,String method){
        if(bmp==null||bmp.isRecycled())return;
        try{
            int w=bmp.getWidth(),h=bmp.getHeight();
            long hash=1469598103934665603L; int sx=Math.max(1,w/32), sy=Math.max(1,h/32);
            for(int y=0;y<h;y+=sy){for(int x=0;x<w;x+=sx){hash^=bmp.getPixel(x,y);hash*=1099511628211L;}}
            capturedFrames++; if(lastFrameHash!=0&&hash!=lastFrameHash)changedFrames++; lastFrameHash=hash; lastFrameCaptureMs=System.currentTimeMillis();
            boolean runOcr=ocrRecognizer!=null&&!ocrBusy&&(manual||System.currentTimeMillis()-lastOcrStartMs>=800);
            if(runOcr){
                ocrBusy=true;lastOcrStartMs=System.currentTimeMillis();final Bitmap ocrBitmap=bmp;
                try{
                    InputImage image=InputImage.fromBitmap(ocrBitmap,0);
                    ocrRecognizer.process(image)
                        .addOnSuccessListener(new com.google.android.gms.tasks.OnSuccessListener<Text>(){public void onSuccess(Text result){try{handleOcrResult(result);}finally{if(!ocrBitmap.isRecycled())ocrBitmap.recycle();ocrBusy=false;}}})
                        .addOnFailureListener(new com.google.android.gms.tasks.OnFailureListener(){public void onFailure(Exception e){lastOcrDecision="OCR error: "+shortErr(e);Log.w("AviatorAI-OCR","recognition failed",e);if(!ocrBitmap.isRecycled())ocrBitmap.recycle();ocrBusy=false;}});
                }catch(Throwable e){if(!ocrBitmap.isRecycled())ocrBitmap.recycle();ocrBusy=false;lastOcrDecision="OCR start failed: "+shortErr(e);}
            }else if(!bmp.isRecycled())bmp.recycle();
            if(frameScanStatus!=null)frameScanStatus.setText(String.format(Locale.US,"HYBRID • %s • frames %d • changed %d • OCR %d • rows %d • %s",method,capturedFrames,changedFrames,ocrFrames,ocrRowsFound,lastOcrDecision));
            Log.d("AviatorAI-FRAME","method="+method+" sample="+capturedFrames+" changed="+changedFrames+" hash="+hash);
        }catch(Throwable e){if(!bmp.isRecycled())bmp.recycle();if(frameScanStatus!=null)frameScanStatus.setText("Frame processing error: "+shortErr(e));Log.w("AviatorAI-FRAME","frame processing failed",e);}
    }

    // ML Kit may split a horizontal history strip into separate Text.Line objects.
    // Cluster lines by their screen Y position before looking for completed-round values.
    static class OcrLineData {
        final String text;
        final Rect box;
        final int centerY;
        final int height;
        OcrLineData(String text, Rect box) {
            this.text = text == null ? "" : text;
            this.box = box;
            this.centerY = box == null ? -1 : (box.top + box.bottom) / 2;
            this.height = box == null ? 0 : Math.max(1, box.height());
        }
    }

    void handleOcrResult(Text result){
        if(activityDestroyed)return;
        ocrFrames++;
        StringBuilder all=new StringBuilder();
        ArrayList<OcrLineData> lines=new ArrayList<OcrLineData>();
        for(Text.TextBlock block:result.getTextBlocks()) for(Text.Line line:block.getLines()){
            String t=line.getText();
            if(all.length()>0)all.append(" | ");
            all.append(t);
            lines.add(new OcrLineData(t,line.getBoundingBox()));
        }
        lastOcrText=all.length()>1200?all.substring(0,1200):all.toString();

        Collections.sort(lines,new Comparator<OcrLineData>(){
            public int compare(OcrLineData a,OcrLineData b){
                if(a.centerY<0 && b.centerY<0)return 0;
                if(a.centerY<0)return 1;
                if(b.centerY<0)return -1;
                return a.centerY-b.centerY;
            }
        });
        // The large central multiplier is a live-flight signal; small text in the history
        // strip is handled separately below. This lets OCR-only/canvas games update the UI.
        updateOcrLiveMultiplier(lines);

        ArrayList<ArrayList<OcrLineData>> rows=new ArrayList<ArrayList<OcrLineData>>();
        ArrayList<OcrLineData> current=null;
        int currentCenter=-1,currentHeight=0;
        for(OcrLineData line:lines){
            if(line.centerY<0){
                ArrayList<OcrLineData> isolated=new ArrayList<OcrLineData>();isolated.add(line);rows.add(isolated);continue;
            }
            int tolerance=Math.max(10,Math.max(line.height,currentHeight)/2+4);
            if(current==null || Math.abs(line.centerY-currentCenter)>tolerance){
                current=new ArrayList<OcrLineData>();rows.add(current);currentCenter=line.centerY;currentHeight=line.height;
            }else{
                currentCenter=(currentCenter+line.centerY)/2;
                currentHeight=Math.max(currentHeight,line.height);
            }
            current.add(line);
        }

        String best=null;int bestScore=0,bestCount=0;
        Pattern tokenPattern=Pattern.compile("(?i)(?<![\\d.])(\\d{1,5}(?:[.,]\\d{1,3})?)\\s*([x×])?\\b");
        for(ArrayList<OcrLineData> row:rows){
            Collections.sort(row,new Comparator<OcrLineData>(){
                public int compare(OcrLineData a,OcrLineData b){
                    int ax=a.box==null?Integer.MAX_VALUE:a.box.left;
                    int bx=b.box==null?Integer.MAX_VALUE:b.box.left;
                    return ax-bx;
                }
            });
            StringBuilder rowText=new StringBuilder();
            for(OcrLineData line:row){if(rowText.length()>0)rowText.append(' ');rowText.append(line.text);}
            String candidate=rowText.toString();
            Matcher m=tokenPattern.matcher(candidate);
            ArrayList<String> values=new ArrayList<String>();int marked=0;
            while(m.find()&&values.size()<35){
                String raw=m.group(1).replace(',','.');
                try{
                    double value=Double.parseDouble(raw);
                    // Multiplier history entries are at least 1.00x; decimal values without
                    // a visible x are retained only when another token in this row confirms it.
                    if(value>=1.0&&value<=100000){values.add(raw);if(m.group(2)!=null)marked++;}
                }catch(Exception ignored){}
            }
            String lower=candidate.toLowerCase(Locale.US);
            // At least three plausible values and at least one visible multiplier marker.
            // This rejects isolated live-flight values and most unrelated UI numbers.
            if(values.size()>=3 && values.size()<=35 && marked>=1){
                int score=values.size()*2+marked*3+(lower.contains("history")?10:0)+(lower.contains("result")?4:0);
                if(score>bestScore){
                    StringBuilder normalized=new StringBuilder();
                    for(String value:values){if(normalized.length()>0)normalized.append(' ');normalized.append(value).append('x');}
                    best=normalized.toString();bestScore=score;bestCount=values.size();
                }
            }
        }
        if(best!=null){
            ocrRowsFound++;
            lastOcrDecision="OCR history-row candidate • "+bestCount+" multiplier values clustered";
            processHistoryRow(best,"screen_ocr",0.65);
            Log.i("AviatorAI-OCR","row="+best);
        }else{
            lastOcrDecision="OCR read frame; no history row • need 3+ aligned multiplier values";
            Log.d("AviatorAI-OCR","text="+lastOcrText);
        }
        if(frameScanStatus!=null)frameScanStatus.setText(String.format(Locale.US,"HYBRID OCR • frames %d • changed %d • OCR %d • rows %d • %s",capturedFrames,changedFrames,ocrFrames,ocrRowsFound,lastOcrDecision));
        if(dataQuality!=null)dataQuality.setText("OCR: "+lastOcrDecision+"\n"+lastOcrLiveDecision+"\nRecognized: "+lastOcrText+"\nHistory: "+historyDiagnostic+"\n"+cloudStatus); refreshUi();
    }

    void updateOcrLiveMultiplier(ArrayList<OcrLineData> lines){
        Pattern livePattern=Pattern.compile("(?i)(?<![\\d.])(\\d{1,5}(?:[.,]\\d{1,3})?)\\s*[x×]");
        int minHeight=Math.max(18,dp(18));int bestHeight=0;double bestValue=0;String bestText="";
        for(OcrLineData line:lines){
            if(line==null||line.box==null||line.height<minHeight)continue;
            Matcher m=livePattern.matcher(line.text);int count=0;double value=0;String raw="";
            while(m.find()&&count<3){try{double x=Double.parseDouble(m.group(1).replace(',','.'));if(x>=1&&x<=100000){count++;value=x;raw=m.group(0);}}catch(Exception ignored){}}
            // A central live multiplier is normally one prominent token; a multi-value line
            // is much more likely to be the history strip and must not become the live value.
            if(count==1&&line.height>bestHeight){bestHeight=line.height;bestValue=value;bestText=raw;}
        }
        if(bestValue>=1){
            double old=liveMultiplier;String key=String.format(Locale.US,"%.3f",bestValue);
            if(Math.abs(old-bestValue)>=0.001||lastFreshRoundMs==0){previousLiveMultiplier=old;liveMultiplier=bestValue;lastRoundValue=key;lastFreshRoundMs=System.currentTimeMillis();lastLiveChangeMs=lastFreshRoundMs;lastOcrLiveDecision="Prominent OCR live multiplier: "+key+"x (line height "+bestHeight+")";}
            else {lastFreshRoundMs=System.currentTimeMillis();lastOcrLiveDecision="OCR live multiplier stable: "+key+"x";}
        }else lastOcrLiveDecision="No prominent live multiplier; scanning rendered frame";
    }

    WebChromeClient debugChrome(final String tag){ return new WebChromeClient(){ @Override public boolean onConsoleMessage(ConsoleMessage m){ Log.w("AviatorAI-"+tag,"JS "+m.messageLevel()+": "+m.message()+" @"+m.sourceId()+":"+m.lineNumber()); return true; } @Override public void onReceivedTitle(WebView v,String title){ super.onReceivedTitle(v,title); } }; }
    WebViewClient debugClient(final String tag){ return new WebViewClient(){ @Override public void onPageFinished(WebView v,String url){ if("MAIN".equals(tag)){ browserStatus.setText("Browser capture: main page connected • scanning rendered DOM + iframe sources"); injectCaptureScript(); discoverIframes(); } else { iframeConnected=1; iframeArmed=false; browserStatus.setText("WebView: Aviator frame connected • waiting for live figures"); probeFrameForFigures(v); } }
        @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){ super.onReceivedError(v,r,e); Log.e("AviatorAI-"+tag,"WebView error: "+e.getErrorCode()+" "+e.getDescription()+" url="+(r==null?"":r.getUrl())); if("FRAME".equals(tag)) status.setText("Status: discovered frame load error • capture retry available"); }
        @Override public void onReceivedHttpError(WebView v,WebResourceRequest r,WebResourceResponse e){ super.onReceivedHttpError(v,r,e); if(r!=null && r.isForMainFrame()) Log.e("AviatorAI-"+tag,"HTTP "+e.getStatusCode()+" url="+r.getUrl()); }
        @Override public boolean onRenderProcessGone(WebView v,RenderProcessGoneDetail d){ Log.e("AviatorAI-"+tag,"WebView renderer gone; didCrash="+(d!=null&&d.didCrash())); if(v==frameBrowser){ iframeConnected=0; try{v.destroy();}catch(Exception ignored){} if(frameBrowser!=null) frameBrowser=null; } else if(v==browser){ try{v.destroy();}catch(Exception ignored){} browser=null; } if(!rendererRestarting){ rendererRestarting=true; browserStatus.setText("Browser capture: renderer stopped • restarting app capture"); new Handler(Looper.getMainLooper()).postDelayed(new Runnable(){public void run(){try{recreate();}catch(Exception ignored){} }},500); } return true; }
    }; }

    void openBrowser(String url){ if(browser==null){ status.setText("Status: browser renderer unavailable • use RECONNECT"); return; } browser.loadUrl(url); browserStatus.setText("Browser capture: loading main source"); }
    void discoverIframes(){ if(browser==null)return; browser.evaluateJavascript("javascript:(function(){try{var a=[];var fs=document.querySelectorAll('iframe');for(var i=0;i<fs.length;i++){var u='';try{u=fs[i].src||fs[i].contentWindow.location.href||'';}catch(e){u=fs[i].getAttribute('src')||'';}if(u)a.push(u);}window.AviatorBridge.capture('IFRAMES\\n'+a.join('\\n'));}catch(e){window.AviatorBridge.capture('IFRAMES\\n');}})()",null); }
    void connectFirstIframe(final String url){ if(frameBrowser==null||url==null||url.length()==0)return; if(url.equals(discoveredFrameUrl) && iframeConnected==1)return; iframeDiscovered=Math.max(iframeDiscovered,1); discoveredFrameUrl=url; iframeConnected=0; frameBrowser.loadUrl(url); }
    void buildBrowserRecovery(){ browserStatus.setText("Browser capture: renderer unavailable • restarting capture"); try{recreate();}catch(Exception e){status.setText("Status: restart required after WebView renderer failure");} }
    void openDiscoveredFrame(){ if(discoveredFrameUrl.length()==0){status.setText("Status: no iframe/AVTalk frame discovered yet • open Aviator first");return;} frameBrowser.setAlpha(1f); frameBrowser.setVisibility(View.VISIBLE); frameBrowser.loadUrl(discoveredFrameUrl); status.setText("Status: opened discovered iframe/frame • capture remains active"); }
    void reconnectCapture(){ try{candidateLast.clear();candidateChanges.clear();lastFreshRoundMs=0;lastLiveChangeMs=0;liveMultiplier=0;previousLiveMultiplier=0;lastRoundValue="";lastCompletedRound=0;iframeConnected=0;iframeDiscovered=0;discoveredFrameUrl="";if(browser==null){buildBrowserRecovery();return;}browser.reload();status.setText("Status: reconnecting SportyBet Aviator capture…");}catch(Exception e){status.setText("Status: reconnect failed • "+shortErr(e));} }
    void probeFrameForFigures(final WebView v){ if(activityDestroyed||v==null)return; v.evaluateJavascript("javascript:(function(){try{var t=(document.body?document.body.innerText:'')+' '+(document.documentElement?document.documentElement.innerText:'');var ok=/\\b\\d{1,5}(?:\\.\\d{1,3})?x\\b/i.test(t);window.AviatorBridge.capture(ok?'FRAME_READY':'FRAME_WAIT');}catch(e){window.AviatorBridge.capture('FRAME_WAIT');}})()",null); if(!iframeArmed) v.postDelayed(new Runnable(){public void run(){if(!activityDestroyed&&!iframeArmed)probeFrameForFigures(v);}},700); }

    String captureScript(){ return "javascript:(function(){try{var rows=[];var els=document.querySelectorAll('[class*=mult],[class*=crash],[class*=coef],[data-testid*=mult],[data-testid*=crash],[aria-label*=mult],[aria-label*=crash],body *');var best='',bestN=0;for(var i=0;i<Math.min(els.length,1200);i++){var e=els[i],t=((e.innerText||e.textContent||e.getAttribute('aria-label')||'')+'').trim();if(!t||t.length>900)continue;var r=e.getBoundingClientRect(),st=document.defaultView.getComputedStyle(e);if(r.width<2||r.height<2||st.visibility==='hidden'||st.display==='none'||st.opacity==='0')continue;var ms=t.match(/\\b\\d{1,5}(?:\\.\\d{1,3})?\\s*x\\b/gi)||[];if(ms.length>=3&&ms.length<=35){var meta=((e.className||'')+' '+(e.getAttribute('data-testid')||'')+' '+(e.getAttribute('aria-label')||'')).toLowerCase();var score=ms.length+(meta.indexOf('history')>=0?15:0)+(meta.indexOf('result')>=0?5:0);if(score>bestN){bestN=score;best=ms.map(function(x){return x.replace(/\\s/g,'').toLowerCase();}).join(',');}}if(!/^\\d{1,5}(?:\\.\\d{1,3})?x$/i.test(t))continue;var meta2=((e.className||'')+' '+(e.getAttribute('data-testid')||'')+' '+(e.getAttribute('aria-label')||'')).toLowerCase();var score2=(meta2.indexOf('mult')>=0||meta2.indexOf('crash')>=0||meta2.indexOf('coef')>=0?100:0)+(parseFloat(st.fontSize)||0)+(r.width>20?10:0)+(r.top<document.documentElement.clientHeight?10:0);var id=location.href+'|'+e.tagName+'|'+Math.round(r.left)+'|'+Math.round(r.top)+'|'+meta2.substring(0,80);rows.push('CAND|'+encodeURIComponent(id)+'|'+t+'|'+score2.toFixed(1));}if(best)rows.unshift('HIST|'+best);var fs=document.querySelectorAll('iframe');for(var j=0;j<fs.length;j++){var u=fs[j].src||'';try{u=fs[j].contentWindow.location.href||u;}catch(e){}if(u)rows.push('IFRAME|'+encodeURIComponent(u));}window.AviatorBridge.capture(rows.join('\\n').substring(0,120000));}catch(e){window.AviatorBridge.capture('ERR|'+e);}})()"; }
    void injectCaptureScript(){ if(activityDestroyed||browser==null)return; browser.evaluateJavascript(captureScript(),null); browser.postDelayed(new Runnable(){public void run(){if(!activityDestroyed)injectCaptureScript();}},900); }
    void injectFrameCaptureScript(final WebView v){ if(activityDestroyed||v==null)return; v.evaluateJavascript(captureScript(),null); v.postDelayed(new Runnable(){public void run(){if(!activityDestroyed)injectFrameCaptureScript(v);}},900); }
    void processBrowserPayload(final String body){ if(activityDestroyed||body==null||body.length()==0)return; runOnUiThread(new Runnable(){public void run(){captureSeq++;String[] lines=body.split("\\n");boolean newAccepted=false;double accepted=0,bestScore=-1;int iframeSeen=0;boolean iframeList=false;for(String line:lines){if(line.equals("FRAME_READY")){iframeArmed=true; injectFrameCaptureScript(frameBrowser); continue;} if(line.equals("FRAME_WAIT")){continue;} if(line.equals("IFRAMES")){iframeList=true;continue;}if(iframeList&&!line.startsWith("CAND|")&&!line.startsWith("IFRAME|")&&line.trim().length()>0){iframeSeen++;if(iframeSeen==1)connectFirstIframe(line.trim());continue;}if(line.startsWith("IFRAME|")){iframeSeen++;continue;}if(line.startsWith("HIST|")){processHistoryRow(line.substring(5),"dom_text",0.90);continue;}if(!line.startsWith("CAND|"))continue; if(body.startsWith("FRAME\n") && !iframeArmed)continue;String[] q=line.split("\\|",4);if(q.length<4)continue;try{String id=URLDecoder.decode(q[1],"UTF-8");double x=Double.parseDouble(q[2].replace("x",""));double score=Double.parseDouble(q[3]);Double prev=candidateLast.put(id,x);if(prev!=null&&Math.abs(prev-x)>0.000001){int ch=candidateChanges.containsKey(id)?candidateChanges.get(id)+1:1;candidateChanges.put(id,ch);if(ch>=2&&score>bestScore){bestScore=score;accepted=x;}}}catch(Exception e){}}iframeDiscovered=Math.max(iframeDiscovered,iframeSeen);if(accepted>=1){String k=String.format(Locale.US,"%.3f",accepted);if(!k.equals(lastRoundValue)){previousLiveMultiplier=liveMultiplier;liveMultiplier=accepted;lastRoundValue=k;lastFreshRoundMs=System.currentTimeMillis();lastLiveChangeMs=lastFreshRoundMs;observationCount++;newAccepted=true;
        // Keep the live flight separate from completed-round history. A falling/resetting
        // multiplier is treated as the end of the previous flight; intermediate ticks are
        // never inserted into model history. This prevents a static 1.44x (or any other
        // in-flight value) from poisoning the learner.
        if(previousLiveMultiplier>1.15 && accepted<=Math.max(1.10,previousLiveMultiplier-0.20)){double completed=previousLiveMultiplier;if(lastCompletedRound<=0 || Math.abs(lastCompletedRound-completed)>0.000001){synchronized(lock){rounds.add(completed);model.observe(completed,rounds.size());while(rounds.size()>1000)rounds.remove(0);}lastCompletedRound=completed;newDataCount++;}}
    }}else{observationCount++;unchangedCaptureCount++;}saveRounds();browserStatus.setText(newAccepted?"Browser capture: FRESH changing live candidate accepted":"Browser capture: connected • no new changing live candidate");sourceMatrix.setText(String.format(Locale.US,"Sources: main page 1/1 • iframe %d/%d • network %s • live candidate %s",iframeConnected,Math.max(iframeDiscovered,iframeConnected),lastSource.length()>0?"connected":"OFF",lastRoundValue.length()>0?lastRoundValue+"x":"none"));dataQuality.setText(String.format(Locale.US,"Capture integrity: rendered page + iframe • observations %d • unchanged %d • changing candidates %d\nHistory-first: %s",observationCount,unchangedCaptureCount,candidateChanges.size(),historyDiagnostic));refreshUi();}}); }
    void processHistoryRow(String raw){ processHistoryRow(raw,"screen_ocr",0.65); }
    void processHistoryRow(String raw,String sourceKind,double ocrConfidence){
        ArrayList<Double> current=new ArrayList<Double>(); Matcher m=Pattern.compile("(?i)(\\d{1,5}(?:\\.\\d{1,3})?)x").matcher(raw);
        while(m.find()&&current.size()<35){try{double x=Double.parseDouble(m.group(1));if(x>=1.0&&x<=100000)current.add(x);}catch(Exception ignored){}}
        if(current.size()<3){historyDiagnostic="history candidate rejected • only "+current.size()+" valid values";return;}
        historyRowsRead++;
        if(lastHistoryRow.isEmpty()){lastHistoryRow=new ArrayList<Double>(current);historyDiagnostic="history row detected • baseline "+current.size()+" values; waiting for next round";return;}
        int overlap=0, added=0;
        // New values are prepended. Find the longest prefix length of the previous row that
        // matches a suffix of the current row. This works when the visible row is clipped too.
        for(int shift=0;shift<current.size();shift++){
            int k=Math.min(lastHistoryRow.size(),current.size()-shift); if(k<=overlap)continue;
            boolean same=true; for(int j=0;j<k;j++){if(Math.abs(current.get(shift+j)-lastHistoryRow.get(j))>0.000001){same=false;break;}}
            if(same){overlap=k;added=shift;}
        }
        if(current.equals(lastHistoryRow)){added=0;overlap=current.size();}
        if(added>0){ArrayList<Double> fresh=new ArrayList<Double>();for(int i=0;i<added;i++)fresh.add(current.get(i));Collections.reverse(fresh);synchronized(lock){for(double x:fresh){rounds.add(x);model.observe(x,rounds.size());newDataCount++;enqueueCloudObservation(x,raw,sourceKind,ocrConfidence);}while(rounds.size()>1000)rounds.remove(0);}lastCompletedRound=fresh.get(fresh.size()-1);lastFreshRoundMs=System.currentTimeMillis();historyDiagnostic="history row active • "+added+" new round(s) recorded • "+current.size()+" values visible";saveRounds();}
        else historyDiagnostic="history row active • no new prefix detected • "+current.size()+" values visible";
        lastHistoryRow=new ArrayList<Double>(current);
    }

    void enqueueCloudObservation(double multiplier,String raw,String sourceKind,double confidenceValue){
        try{
            JSONArray queue;
            String saved=prefs.getString("cloud_queue","[]");
            try{queue=new JSONArray(saved);}catch(Exception bad){queue=new JSONArray();}
            JSONObject item=new JSONObject();item.put("event_id",UUID.randomUUID().toString());item.put("session_id",sessionId);item.put("observed_at",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX",Locale.US).format(new java.util.Date()));item.put("multiplier",multiplier);item.put("ocr_confidence",Math.max(0,Math.min(1,confidenceValue)));item.put("raw_ocr_text",raw==null?"":raw.substring(0,Math.min(2000,raw.length())));item.put("source_kind",sourceKind);item.put("game_source",discoveredFrameUrl.length()>0?discoveredFrameUrl:"Aviator URL crawler");
            queue.put(item);while(queue.length()>500){JSONArray trim=new JSONArray();for(int i=queue.length()-500;i<queue.length();i++)trim.put(queue.get(i));queue=trim;}
            prefs.edit().putString("cloud_queue",queue.toString()).apply();cloudStatus="Cloud sync: "+queue.length()+" reading(s) queued";mainHandler.post(new Runnable(){public void run(){if(cloudBadge!=null)cloudBadge.setText(cloudStatus);}});syncCloudQueue();
        }catch(Exception e){cloudStatus="Cloud sync: could not queue observation";Log.w("AviatorAI-CLOUD","queue failed",e);}
    }
    void syncCloudQueue(){
        if(activityDestroyed||cloudSyncInFlight)return;
        final String saved=prefs.getString("cloud_queue","[]");
        final JSONArray queue;try{queue=new JSONArray(saved);}catch(Exception e){return;}
        if(queue.length()==0){cloudStatus="Cloud sync: idle • no pending readings";if(cloudBadge!=null)mainHandler.post(new Runnable(){public void run(){if(cloudBadge!=null)cloudBadge.setText(cloudStatus);}});return;}
        cloudSyncInFlight=true;
        new Thread(new Runnable(){public void run(){
            boolean didUpload=false;
            try{
                String token=cloudAccessToken;
                if(token.length()==0)token=createAnonymousSession();
                JSONArray batch=new JSONArray();for(int i=0;i<Math.min(100,queue.length());i++)batch.put(queue.getJSONObject(i));
                JSONObject payload=new JSONObject();payload.put("device_id",deviceId);payload.put("app_version","25.0-Hybrid-Capture-Sports-UI");payload.put("observations",batch);
                HttpURLConnection c=postJson(SUPABASE_URL+"/functions/v1/aviator-ingest",token,payload.toString());int code=c.getResponseCode();String response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream());c.disconnect();
                if(code==401){token=refreshAnonymousSession();c=postJson(SUPABASE_URL+"/functions/v1/aviator-ingest",token,payload.toString());code=c.getResponseCode();response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream());c.disconnect();}
                if(code<200||code>=300)throw new IOException("ingest HTTP "+code+": "+response.substring(0,Math.min(220,response.length())));
                JSONObject result=new JSONObject(response);final int inserted=result.optInt("inserted",0),duplicates=result.optInt("duplicates_ignored",0);
                java.util.HashSet<String> sentIds=new java.util.HashSet<String>();for(int i=0;i<batch.length();i++)sentIds.add(batch.getJSONObject(i).optString("event_id",""));
                JSONArray latestQueue;try{latestQueue=new JSONArray(prefs.getString("cloud_queue","[]"));}catch(Exception bad){latestQueue=new JSONArray();}
                JSONArray remaining=new JSONArray();for(int i=0;i<latestQueue.length();i++){JSONObject pending=latestQueue.getJSONObject(i);if(!sentIds.contains(pending.optString("event_id","")))remaining.put(pending);}
                prefs.edit().putString("cloud_queue",remaining.toString()).apply();
                cloudStatus="Cloud sync: uploaded "+inserted+" • duplicates "+duplicates+" • queued "+remaining.length();didUpload=true;
            }catch(Exception e){cloudStatus="Cloud sync pending: "+shortErr(e);Log.w("AviatorAI-CLOUD","sync failed",e);}
            finally{cloudSyncInFlight=false;if(!activityDestroyed)runOnUiThread(new Runnable(){public void run(){if(cloudBadge!=null)cloudBadge.setText(cloudStatus);if(dataQuality!=null)dataQuality.setText(dataQuality.getText()+"\n"+cloudStatus);if(sourceMatrix!=null)sourceMatrix.setText(sourceMatrix.getText()+"\n"+cloudStatus);}});if(didUpload&&!activityDestroyed&&prefs.getString("cloud_queue","[]").length()>2)mainHandler.postDelayed(new Runnable(){public void run(){syncCloudQueue();}},800);}
        }}).start();
    }
    HttpURLConnection postJson(String url,String token,String body)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("apikey",SUPABASE_ANON_KEY);c.setRequestProperty("Authorization","Bearer "+token);byte[] bytes=body.getBytes("UTF-8");c.getOutputStream().write(bytes);c.getOutputStream().close();return c;
    }
    String createAnonymousSession()throws Exception{
        JSONObject body=new JSONObject();body.put("data",new JSONObject());
        HttpURLConnection c=postJson(SUPABASE_URL+"/auth/v1/signup",SUPABASE_ANON_KEY,body.toString());int code=c.getResponseCode();String response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream());c.disconnect();
        if(code<200||code>=300)throw new IOException("anonymous auth HTTP "+code+": "+response.substring(0,Math.min(220,response.length())));
        JSONObject obj=new JSONObject(response);String access=obj.optString("access_token","");String refresh=obj.optString("refresh_token","");if(access.length()==0)throw new IOException("auth returned no access token; anonymous sign-in may be disabled");
        cloudAccessToken=access;cloudRefreshToken=refresh;prefs.edit().putString("cloud_access_token",access).putString("cloud_refresh_token",refresh).apply();return access;
    }
    String refreshAnonymousSession()throws Exception{
        if(cloudRefreshToken.length()==0){cloudAccessToken="";return createAnonymousSession();}
        JSONObject body=new JSONObject();body.put("refresh_token",cloudRefreshToken);
        HttpURLConnection c=postJson(SUPABASE_URL+"/auth/v1/token?grant_type=refresh_token",SUPABASE_ANON_KEY,body.toString());int code=c.getResponseCode();String response=read(code>=200&&code<400?c.getInputStream():c.getErrorStream());c.disconnect();
        if(code<200||code>=300){cloudAccessToken="";cloudRefreshToken="";prefs.edit().remove("cloud_access_token").remove("cloud_refresh_token").apply();return createAnonymousSession();}
        JSONObject obj=new JSONObject(response);cloudAccessToken=obj.optString("access_token","");cloudRefreshToken=obj.optString("refresh_token",cloudRefreshToken);prefs.edit().putString("cloud_access_token",cloudAccessToken).putString("cloud_refresh_token",cloudRefreshToken).apply();if(cloudAccessToken.length()==0)throw new IOException("token refresh returned no access token");return cloudAccessToken;
    }

    void loadRounds(){ String s=prefs.getString("rounds",""); if(s.length()==0)return; String[] p=s.split(","); synchronized(lock){ for(String q:p)try{double x=Double.parseDouble(q);if(x>=1&&x<=100000)rounds.add(x);}catch(Exception e){} } }
    void saveRounds(){ StringBuilder b=new StringBuilder(); synchronized(lock){ for(double x:rounds){if(b.length()>0)b.append(',');b.append(x);} } prefs.edit().putString("rounds",b.toString()).putLong("observation_count",observationCount).putLong("unchanged_capture_count",unchangedCaptureCount).putLong("gap_count",gapCount).apply(); }
    void addManual(){ String s=manual.getText().toString(); Matcher m=Pattern.compile("(?:^|[^0-9.])(\\d+(?:\\.\\d+)?)[xX]?").matcher(s); int n=0; synchronized(lock){while(m.find()){try{double x=Double.parseDouble(m.group(1));if(x>=1&&x<=100000){rounds.add(x);model.observe(x,rounds.size());n++;}}catch(Exception e){}}while(rounds.size()>1000)rounds.remove(0);} saveRounds(); manual.setText(""); status.setText("Status: added "+n+" round(s) • AI updated"); refreshUi(); }

    void startLive(){ stopLive(); pollMs=500; status.setText("Status: adaptive capture • multi-source mode • deduplicated rounds"); scheduler=Executors.newSingleThreadScheduledExecutor(); scheduler.schedule(new Runnable(){ public void run(){ fetchLive(); if(scheduler!=null&&!scheduler.isShutdown()) scheduleNext(); }},0,TimeUnit.MILLISECONDS); }
    void scheduleNext(){ if(scheduler==null||scheduler.isShutdown())return; scheduler.schedule(new Runnable(){ public void run(){ fetchLive(); if(scheduler!=null&&!scheduler.isShutdown()) scheduleNext(); }},pollMs,TimeUnit.MILLISECONDS); }
    void stopLive(){if(scheduler!=null){scheduler.shutdownNow();scheduler=null;}}
    @Override protected void onDestroy(){activityDestroyed=true;stopLive();if(frameCaptureTask!=null)mainHandler.removeCallbacks(frameCaptureTask);if(watchdogTask!=null)mainHandler.removeCallbacks(watchdogTask);try{if(ocrRecognizer!=null)ocrRecognizer.close();}catch(Exception ignored){}try{if(browser!=null)browser.stopLoading();if(frameBrowser!=null)frameBrowser.stopLoading();}catch(Exception ignored){}super.onDestroy();}

    void fetchLive(){ if(fetchInFlight)return; final String raw=endpoint.getText().toString().trim(); if(raw.length()==0)return; fetchInFlight=true; final long started=System.currentTimeMillis(); new Thread(new Runnable(){ public void run(){ try{ String[] urls=raw.split("\\s*,\\s*"); ArrayList<Double> all=new ArrayList<Double>(); String chosen=""; int ok=0; long maxLatency=0; for(String url:urls){ if(url.trim().length()==0)continue; try{ long t=System.currentTimeMillis(); URL u=new URL(url.trim()); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(1800); c.setReadTimeout(2500); c.setUseCaches(false); c.setRequestProperty("User-Agent","Mozilla/5.0 (Android) AviatorLiveAnalyzer"); c.setRequestProperty("Accept","application/json,text/html,*/*"); int code=c.getResponseCode(); InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream(); String body=read(in);c.disconnect(); ArrayList<Double> vals=parseMultipliers(body); if(vals.size()>0){ok++; if(chosen.length()==0)chosen=url.trim(); all.addAll(vals); maxLatency=Math.max(maxLatency,System.currentTimeMillis()-t);}}catch(Exception ignored){}} if(all.size()==0)throw new IOException("No public multiplier data detected"); ArrayList<Double> vals=normalizeValues(all); String fp=vals.toString(); final boolean changed=!fp.equals(lastFingerprint); lastFingerprint=fp; lastSource=chosen; final int vc=vals.size(); final long latency=System.currentTimeMillis()-started; lastLatencyMs=latency; double crawlerNewest=vals.get(vals.size()-1); String crawlerKey=String.format(Locale.US,"%.3f",crawlerNewest); boolean crawlerRoundChanged=!crawlerKey.equals(lastCrawlerValue); if(crawlerRoundChanged) lastCrawlerValue=crawlerKey; synchronized(lock){ observationCount += vc; if(!changed) unchangedCaptureCount += vc; if(lastFetchMs>0 && System.currentTimeMillis()-lastFetchMs>Math.max(5000,pollMs*8))gapCount++; lastFetchMs=System.currentTimeMillis(); if(changed){ newDataCount += vc; } if(crawlerRoundChanged && crawlerNewest>=1.0 && crawlerNewest<=100000 && (lastCompletedRound<=0 || Math.abs(lastCompletedRound-crawlerNewest)>0.000001)){ rounds.add(crawlerNewest); model.observe(crawlerNewest,rounds.size()); while(rounds.size()>1000)rounds.remove(0); lastCompletedRound=crawlerNewest; enqueueCloudObservation(crawlerNewest,"URL crawler parsed multiplier "+String.format(Locale.US,"%.3fx",crawlerNewest),"dom_text",0.55); } } saveRounds(); pollMs=changed?250:900; final int sources=ok; runOnUiThread(new Runnable(){ public void run(){ status.setText(changed?"Status: URL crawler changed • "+sources+" source(s) • learner updated":"Status: URL crawler unchanged • monitoring only"); dataQuality.setText(String.format(Locale.US,"Data quality: %s source(s) • latency %d ms • polling %d ms • observations %d • unchanged %d • gaps %d",sources,latency,pollMs,observationCount,unchangedCaptureCount,gapCount)); refreshUi(); }}); }catch(final Exception e){pollMs=Math.min(3000,Math.max(700,pollMs+300));runOnUiThread(new Runnable(){ public void run(){ status.setText("Status: source unavailable • adaptive fallback • "+shortErr(e)); dataQuality.setText("Data quality: degraded • retrying at "+pollMs+" ms"); }});} finally{fetchInFlight=false;} }}).start(); }
    ArrayList<Double> normalizeValues(ArrayList<Double> in){ArrayList<Double> out=new ArrayList<Double>(); for(double x:in){if(x>=1&&x<=100000 && (out.size()==0 || Math.abs(out.get(out.size()-1)-x)>0.000001))out.add(x); if(out.size()>=60)break;} return out;}
    String shortErr(Exception e){String s=e.getMessage();return s==null?e.getClass().getSimpleName():s;}
    String read(InputStream in)throws Exception{if(in==null)return "";BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder b=new StringBuilder();String line;int chars=0;while((line=r.readLine())!=null&&chars<500000){b.append(line).append('\n');chars+=line.length();}r.close();return b.toString();}
    ArrayList<Double> parseMultipliers(String s){ArrayList<Double> out=new ArrayList<Double>();String[] ps={"(?i)(?:multiplier|crash|coef|coefficient|odds)[^0-9]{0,60}(\\d+(?:\\.\\d+)?)x","(?i)(\\d+(?:\\.\\d+)?)x"};for(String p:ps){Matcher m=Pattern.compile(p).matcher(s);while(m.find()&&out.size()<60){try{double x=Double.parseDouble(m.group(1));if(x>=1&&x<=100000)out.add(x);}catch(Exception e){}}if(out.size()>0)break;}return out;}

    void refreshUi(){
        ArrayList<Double>a; synchronized(lock){a=new ArrayList<Double>(rounds);}
        boolean fresh=liveMultiplier>0 && lastFreshRoundMs>0 && System.currentTimeMillis()-lastFreshRoundMs<4500;
        if(fresh) latest.setText(String.format(Locale.US,"LIVE %.2fx",liveMultiplier)); else latest.setText("WAITING FOR LIVE FIGURES");
        if(!fresh){ predictionReady=false; prediction.setText("AI is waiting for a live reading"); confidence.setText("Estimate hidden until a fresh reading is available"); intelligence.setText("Model: waiting for live input"); audit.setText("Prediction state: hidden"); }
        else if(a.size()<8){ predictionReady=false; prediction.setText("AI is learning from completed rounds…"); confidence.setText("Estimate hidden • need more completed rounds"); intelligence.setText("Model: "+a.size()+" completed rounds"); audit.setText("Prediction state: learning"); }
        else if(aiBusy){ predictionReady=false; prediction.setText("AI CALCULATING…"); confidence.setText("Reading → calculation → learning → analysis → estimate"); audit.setText("Prediction state: processing"); }
        else {
            final Analysis z=analyze(a); predictionReady=z.signal; if(z.signal){prediction.setText(String.format(Locale.US,"ESTIMATE %.2fx   •   BAND %.2fx–%.2fx",z.center,z.lo,z.hi)); confidence.setText(String.format(Locale.US,"Confidence %.0f/100 • model agreement %.0f%%",z.conf,z.agreement)); intelligence.setText(String.format(Locale.US,"Online learner %.0f%% • k-NN %.0f%% • baseline %.0f%%",z.acc,z.nnAcc,z.medAcc)); audit.setText("Prediction state: READY • based on completed-round learning");}else{prediction.setText("NO RELIABLE ESTIMATE");confidence.setText("Models disagree or data is anomalous");intelligence.setText("AI completed analysis but did not pass the reliability gate");audit.setText("Prediction state: blocked");}
            accuracy.setText(String.format(Locale.US,"Learning: %d rounds • backtest %.1f%%",a.size(),z.acc)); dashboard.setText(String.format(Locale.US,"Calculation: center %.2fx • spread %.2fx • regime %s",z.center,(z.hi-z.lo)/2.0,z.regime)); anomaly.setText(String.format(Locale.US,"Analysis: anomaly %.2f • agreement %.1f%%",z.anom,z.agreement)); lastAiCompletedMs=System.currentTimeMillis();
        }
        if(chart!=null)chart.setData(a); if(historyBox!=null){historyBox.removeAllViews();int start=Math.max(0,a.size()-20);for(int i=a.size()-1;i>=start;i--){TextView h=text(String.format(Locale.US,"%03d   %.2fx",i+1,a.get(i)),12,Color.WHITE);h.setPadding(dp(8),dp(6),dp(8),dp(6));historyBox.addView(h);}}
        if(sourceMatrix!=null)sourceMatrix.setText(String.format(Locale.US,"Two sources: URL crawler %s • iframe %s\n%s",lastSource.length()>0?"ON":"OFF",iframeArmed?"ON":"waiting for figures",cloudStatus));
        if(sessionHealth!=null)sessionHealth.setText(String.format(Locale.US,"Source health: crawler %s • iframe %s • %d observations • %d unchanged",lastSource.length()>0?"connected":"waiting",iframeArmed?"reading":"waiting",observationCount,unchangedCaptureCount));
        updateAdvancedInsights();
    }
    void startUiWatchdog(){watchdogTask=new Runnable(){public void run(){if(activityDestroyed)return;long age=lastFreshRoundMs==0?Long.MAX_VALUE:System.currentTimeMillis()-lastFreshRoundMs;if(age>4500){liveMultiplier=0.0;if(latest!=null)latest.setText("NO FRESH LIVE READING");if(prediction!=null)prediction.setText("Statistical analysis: no fresh live reading detected");if(intelligence!=null)intelligence.setText("Pattern analysis: waiting for a changing live multiplier");if(confidence!=null)confidence.setText("Confidence: unavailable until a fresh live reading is captured");if(aiState!=null)aiState.setText("Analytics: PAUSED • stale/unchanged live source • automatic recovery available");}else if(liveMultiplier>0&&latest!=null)latest.setText(String.format(Locale.US,"%.2fx",liveMultiplier));mainHandler.postDelayed(this,1000);}};mainHandler.postDelayed(watchdogTask,1000);}
    void updateAdvancedInsights(){
        ArrayList<Double>a; synchronized(lock){a=new ArrayList<Double>(rounds);} if(insightBox==null)return;
        if(a.size()<5){insightBox.setText("Insights: add at least 5 rounds for distribution, streak and volatility analysis");sessionHealth.setText("Session health: waiting for more observations");return;}
        int low=0,mid=0,high=0,mega=0; for(double x:a){if(x<1.5)low++;else if(x<3)mid++;else if(x<10)high++;else mega++;}
        int streak=0,best=0; for(int i=a.size()-1;i>=0;i--){if(a.get(i)<1.5)streak++;else break;} for(int i=0,c=0;i<a.size();i++){if(a.get(i)<1.5){c++;best=Math.max(best,c);}else c=0;}
        double q25=quantile(a,.25), q50=quantile(a,.50), q75=quantile(a,.75), mad=recentMad(a), cv=robustCv(a);
        String state=streak>=5?"LOW-MULTIPLIER STREAK":(cv>.55?"HIGH VOLATILITY":"NORMAL/MIXED");
        insightBox.setText(String.format(Locale.US,"Distribution: <1.50x %d%% • 1.50–2.99x %d%% • 3–9.99x %d%% • 10x+ %d%%\nQuartiles: %.2fx / %.2fx / %.2fx • robust MAD %.2f • volatility %.2f\nCurrent streak: %d low rounds • longest low streak: %d • regime: %s",100*low/a.size(),100*mid/a.size(),100*high/a.size(),100*mega/a.size(),q25,q50,q75,mad,cv,streak,best,state));
        long age=lastFreshRoundMs==0?0:System.currentTimeMillis()-lastFreshRoundMs; String freshness=lastFreshRoundMs==0?"no fresh capture":(age<5000?"fresh":(age<30000?"aging":"stale"));
        sessionHealth.setText(String.format(Locale.US,"Session health: %s • %d stored rounds • %d observations • %d unchanged captures • %d gaps • last source %s",freshness,a.size(),observationCount,unchangedCaptureCount,gapCount,lastSource.length()==0?"manual/local":lastSource));
    }

    void runSimulation(int count){
        ArrayList<Double>a; synchronized(lock){a=new ArrayList<Double>(rounds);} if(a.size()<10){simulationBox.setText("Simulation: need at least 10 historical rounds");return;}
        double q25=quantile(a,.25), q50=quantile(a,.50), q75=quantile(a,.75); Random r=new Random(); int low=0,high=0; double sum=0;
        for(int i=0;i<count;i++){double u=r.nextDouble();double x;if(u<.25)x=Math.max(1.01,q25*(.75+.5*r.nextDouble()));else if(u<.5)x=q50*(.8+.4*r.nextDouble());else if(u<.75)x=q75*(.75+.5*r.nextDouble());else x=Math.min(100,q75*(1+r.nextDouble()));sum+=x;if(x<1.5)low++;if(x>=5)high++;}
        simulationCount+=count; double avg=sum/count; simulationBox.setText(String.format(Locale.US,"Simulation: %d synthetic rounds • avg %.2fx • <1.50x %d%% • 5x+ %d%% • synthetic only; not predictions and not added to history",count,avg,100*low/count,100*high/count));
    }

    String roundsCsv(){StringBuilder b=new StringBuilder("index,multiplier\n"); synchronized(lock){for(int i=0;i<rounds.size();i++)b.append(i+1).append(',').append(String.format(Locale.US,"%.4f",rounds.get(i))).append('\n');}return b.toString();}
    void exportCsv(){try{String csv=roundsCsv();Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/csv");i.putExtra(Intent.EXTRA_SUBJECT,"Aviator AI Analyzer round history");i.putExtra(Intent.EXTRA_TEXT,csv);startActivity(Intent.createChooser(i,"Export round history"));}catch(Exception e){status.setText("Status: export unavailable on this device");}}
    String sha256(String s)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] d=md.digest(s.getBytes("UTF-8"));StringBuilder b=new StringBuilder();for(byte x:d)b.append(String.format(Locale.US,"%02x",x&255));return b.toString();}
    void updateFingerprint(){try{String f=sha256(roundsCsv());fairnessBox.setText("Dataset fingerprint: "+f+" • changes whenever history changes");}catch(Exception e){fairnessBox.setText("Dataset fingerprint: unavailable");}}
    void verifyFingerprint(String expected){if(expected==null||expected.trim().length()==0){fairnessBox.setText("Verification: enter an expected SHA-256 hash first");return;}try{String actual=sha256(roundsCsv());boolean ok=actual.equalsIgnoreCase(expected.trim());fairnessBox.setText("Verification: "+(ok?"MATCH — supplied hash matches this local dataset":"NO MATCH — supplied hash differs")+"\nLocal: "+actual);}catch(Exception e){fairnessBox.setText("Verification: unavailable");}}

    Analysis analyze(ArrayList<Double>a){
        int n=a.size(); double[] f=features(a,n); double pred=model.predict(f); Intelligence nn=nearestPattern(a);
        double median=median(a,Math.max(0,n-Math.min(20,n))); double q25=quantile(a,.25), q75=quantile(a,.75);
        double regimeBias=regimeAdjustment(a,regime(a));
        double center=Math.max(1.01,Math.min(100,.48*pred+.27*nn.value+.15*median+.10*regimeBias));
        double spread=Math.max(.10,Math.min(8,Math.max(q75-q25, recentMad(a)*2.2)));
        double lo=Math.max(1.01,center-spread),hi=center+spread;
        double acc=model.backtest(a), nnAcc=nearestBacktest(a), medAcc=medianBacktest(a);
        double sample=Math.min(1,n/200.0), stability=1-Math.min(1,robustCv(a));
        double agreement=100-Math.min(100,((Math.abs(pred-nn.value)/Math.max(1,pred))*.65+(Math.abs(pred-median)/Math.max(1,pred))*.35)*100);
        double cal=calibrationScore(a); double conf=100*(.20*sample+.14*Math.max(0,stability)+.18*(acc/100)+.16*(nnAcc/100)+.10*(medAcc/100)+.12*(agreement/100)+.10*(cal/100));
        String reg=regime(a); boolean signal=conf>=58 && agreement>=55 && cal>=45 && n>=20 && anomalyScore(a)<3.5;
        double mae=backtestMae(a),medErr=backtestMedianError(a);
        Analysis z=new Analysis(); z.lo=lo;z.hi=hi;z.center=center;z.acc=acc;z.conf=conf;z.tested=Math.max(0,n-8);z.nearest=nn.value;z.nlo=Math.max(1.01,nn.value*Math.exp(-nn.spread));z.nhi=nn.value*Math.exp(nn.spread);z.match=nn.match;z.agreement=agreement;z.regime=reg;z.mae=mae;z.medErr=medErr;z.signal=signal;z.nnAcc=nnAcc;z.medAcc=medAcc;z.cal=cal;z.anom=anomalyScore(a);return z;
    }
    String regime(ArrayList<Double>a){int k=Math.min(30,a.size());double low=0,high=0;double m=0;for(int i=a.size()-k;i<a.size();i++){double x=a.get(i);m+=x;if(x<1.5)low++;if(x>=5)high++;}m/=k;if(low/k>.65)return "LOW-heavy";if(high/k>.18)return "HIGH-volatility";return "MIXED";}
    double backtestMae(ArrayList<Double>a){if(a.size()<10)return 0;double e=0;int c=0;for(int i=8;i<a.size();i++){double p=model.predict(features(a,i));e+=Math.abs(p-a.get(i));c++;}return c==0?0:e/c;}
    double backtestMedianError(ArrayList<Double>a){if(a.size()<10)return 0;ArrayList<Double>e=new ArrayList<Double>();for(int i=8;i<a.size();i++){double p=model.predict(features(a,i));e.add(Math.abs(p-a.get(i))/Math.max(.01,a.get(i))*100);}Collections.sort(e);return e.get(e.size()/2);}
    double[] features(ArrayList<Double>a,int n){int k=Math.min(20,n);double mean=0,mean2=0;for(int i=n-k;i<n;i++){double l=Math.log(Math.max(1.0,a.get(i)));mean+=l;mean2+=l*l;}mean/=k;double sd=Math.sqrt(Math.max(0,mean2/k-mean*mean));double last=Math.log(Math.max(1,a.get(n-1)));double prev=Math.log(Math.max(1,a.get(Math.max(0,n-3))));double trend=last-prev;double low=0;for(int i=n-k;i<n;i++)if(a.get(i)<1.5)low++;low/=k;return new double[]{1,mean,sd,last,trend,low};}
    static class Analysis{double lo,hi,center,acc,conf,nearest,nlo,nhi,match,mae,medErr,agreement,nnAcc,medAcc,cal,anom;String regime;int tested;boolean signal;}
    static class Intelligence{double value,spread,match; Intelligence(double v,double s,double m){value=v;spread=s;match=m;}}

    double quantile(ArrayList<Double>a,double q){ if(a.size()==0)return 0; ArrayList<Double>x=new ArrayList<Double>(a); Collections.sort(x); double pos=q*(x.size()-1); int lo=(int)Math.floor(pos), hi=(int)Math.ceil(pos); if(lo==hi)return x.get(lo); return x.get(lo)+(x.get(hi)-x.get(lo))*(pos-lo); }
    double recentMad(ArrayList<Double>a){ int k=Math.min(30,a.size()); ArrayList<Double>x=new ArrayList<Double>(); for(int i=a.size()-k;i<a.size();i++)x.add(a.get(i)); double m=median(x,0); ArrayList<Double>d=new ArrayList<Double>(); for(double v:x)d.add(Math.abs(v-m)); return median(d,0); }
    double robustCv(ArrayList<Double>a){ double m=median(a,Math.max(0,a.size()-30)); return recentMad(a)/Math.max(.05,m); }
    double regimeAdjustment(ArrayList<Double>a,String r){ if(r.equals("LOW-heavy"))return Math.max(1.01,quantile(a,.40)); if(r.equals("HIGH-volatility"))return Math.min(100,quantile(a,.70)); return median(a,Math.max(0,a.size()-20)); }
    double nearestBacktest(ArrayList<Double>a){ if(a.size()<14)return 0; int hit=0,total=0; for(int i=8;i<a.size();i++){ ArrayList<Double> pre=new ArrayList<Double>(a.subList(0,i)); Intelligence z=nearestPattern(pre); if(Math.abs(z.value-a.get(i))/Math.max(.01,a.get(i))<=.15)hit++; total++; } return total==0?0:100.0*hit/total; }
    double medianBacktest(ArrayList<Double>a){ if(a.size()<8)return 0; int hit=0,total=0; for(int i=8;i<a.size();i++){ ArrayList<Double> pre=new ArrayList<Double>(a.subList(0,i)); double p=median(pre,Math.max(0,pre.size()-12)); if(Math.abs(p-a.get(i))/Math.max(.01,a.get(i))<=.15)hit++; total++; } return total==0?0:100.0*hit/total; }
    double calibrationScore(ArrayList<Double>a){ if(a.size()<20)return 0; int bins=5; int[] count=new int[bins],covered=new int[bins]; for(int i=12;i<a.size();i++){ ArrayList<Double> pre=new ArrayList<Double>(a.subList(0,i)); Analysis z=analyzeCore(pre); int b=Math.min(bins-1,Math.max(0,(int)(z.conf/20))); count[b]++; if(a.get(i)>=z.lo&&a.get(i)<=z.hi)covered[b]++; } double err=0,weight=0; for(int i=0;i<bins;i++){if(count[i]>0){double observed=100.0*covered[i]/count[i],target=(i*20+10);err+=Math.abs(observed-target)*count[i];weight+=count[i];}} return weight==0?0:Math.max(0,100-err/weight); }
    Analysis analyzeCore(ArrayList<Double>a){ Analysis z=new Analysis(); if(a.size()<5){z.conf=20;z.lo=1.01;z.hi=2;return z;} double pred=model.predict(features(a,a.size())); Intelligence nn=nearestPattern(a); double med=median(a,Math.max(0,a.size()-12)); double c=.55*pred+.25*nn.value+.20*med; double sp=Math.max(.12,Math.min(6,recentMad(a)*2.2)); z.center=c;z.lo=Math.max(1.01,c-sp);z.hi=c+sp;double ag=100-Math.min(100,Math.abs(pred-nn.value)/Math.max(1,pred)*100);z.conf=100*(.35*Math.min(1,a.size()/200.0)+.25*(nn.match/100)+.20*(ag/100)+.20*(model.backtest(a)/100));return z; }
    double anomalyScore(ArrayList<Double>a){ if(a.size()<12)return 0; double med=median(a,Math.max(0,a.size()-30)); double mad=Math.max(.05,recentMad(a)); return Math.abs(a.get(a.size()-1)-med)/(1.4826*mad); }
    void runReplay(){ ArrayList<Double>a; synchronized(lock){a=new ArrayList<Double>(rounds);} if(a.size()<20){replayStatus.setText("Replay: need at least 20 stored rounds");return;} int hit=0,total=0; double mae=0; for(int i=12;i<a.size();i++){ArrayList<Double>pre=new ArrayList<Double>(a.subList(0,i)); Analysis z=analyzeCore(pre); double actual=a.get(i); if(Math.abs(z.center-actual)/Math.max(.01,actual)<=.15)hit++; mae+=Math.abs(z.center-actual); total++;} double rate=100.0*hit/total; replayMode=true; replayStatus.setText(String.format(Locale.US,"Replay complete: %d rounds tested • ±15%% hit %.1f%% • MAE %.2fx • no bets placed",total,rate,mae/Math.max(1,total))); replayMode=false; }

    Intelligence nearestPattern(ArrayList<Double>a){int n=a.size();int k=Math.min(6,n-1);if(k<3)return new Intelligence(a.get(n-1),.35,0);double[] q=windowFeatures(a,n,k);ArrayList<double[]> hits=new ArrayList<double[]>();for(int i=Math.max(k,5);i<n-1;i++){double[] h=windowFeatures(a,i,k);double dist=0;for(int j=0;j<q.length;j++){double z=q[j]-h[j];dist+=z*z;}hits.add(new double[]{dist,a.get(i)});}Collections.sort(hits,new Comparator<double[]>(){public int compare(double[]x,double[]y){return Double.compare(x[0],y[0]);}});int take=Math.min(5,hits.size());double sum=0,ws=0,spread=0;for(int i=0;i<take;i++){double w=1.0/(.05+hits.get(i)[0]);sum+=w*hits.get(i)[1];ws+=w;spread+=w*Math.abs(hits.get(i)[1]-(ws==0?hits.get(i)[1]:sum/ws));}double value=ws==0?a.get(n-1):sum/ws;double recentMedian=median(a,Math.max(0,n-Math.min(12,n)));value=Math.max(1.01,Math.min(100,.70*value+.30*recentMedian));double best=take==0?8:hits.get(0)[0];double s=take==0?.5:Math.max(.12,Math.min(1.5,Math.sqrt(best)/2.0));double match=100*Math.exp(-Math.min(8,best));return new Intelligence(value,s,match);}
    double[] windowFeatures(ArrayList<Double>a,int end,int k){double sum=0,ss=0;for(int i=end-k;i<end;i++){double x=Math.log(Math.max(1,a.get(i)));sum+=x;ss+=x*x;}double m=sum/k;double sd=Math.sqrt(Math.max(0,ss/k-m*m));double last=Math.log(Math.max(1,a.get(end-1)));double low=0;for(int i=end-k;i<end;i++)if(a.get(i)<1.5)low++;return new double[]{m,sd,last,low/k};}
    double median(ArrayList<Double>a,int from){ArrayList<Double>x=new ArrayList<Double>();for(int i=from;i<a.size();i++)x.add(a.get(i));Collections.sort(x);int n=x.size();return n%2==1?x.get(n/2):(x.get(n/2-1)+x.get(n/2))/2.0;}

    class OnlineModel{
        double[] w={0.35,1.0,-0.20,0.25,0.08,-0.30}; double lr=.025; int seen=0; android.content.SharedPreferences p;
        OnlineModel(android.content.SharedPreferences p){this.p=p;for(int i=0;i<w.length;i++)w[i]=p.getFloat("w"+i,(float)w[i]);seen=p.getInt("seen",0);}
        void save(){android.content.SharedPreferences.Editor e=p.edit();for(int i=0;i<w.length;i++)e.putFloat("w"+i,(float)w[i]);e.putInt("seen",seen);e.apply();}
        double predict(double[]f){double y=0;for(int i=0;i<w.length;i++)y+=w[i]*f[i];return Math.max(1.01,Math.min(10000,Math.exp(y)));}
        void observe(double actual,int index){if(index<3)return;ArrayList<Double>a; synchronized(lock){a=new ArrayList<Double>(rounds);} if(a.size()<3)return; int n=a.size()-1;double[] f=features(a,n);double target=Math.log(Math.max(1,actual));double pred=0;for(int i=0;i<w.length;i++)pred+=w[i]*f[i];double err=target-pred;double clip=Math.max(-1,Math.min(1,err));for(int i=0;i<w.length;i++)w[i]+=lr*clip*f[i]/(1+Math.abs(f[i]));seen++;if(seen%3==0)save();}
        double backtest(ArrayList<Double>a){if(a.size()<8)return 0;int hits=0,total=0;double[] ww=w.clone();for(int i=5;i<a.size();i++){double[] f=features(a,i);double y=0;for(int j=0;j<ww.length;j++)y+=ww[j]*f[j];double pred=Math.exp(y),actual=a.get(i);if(Math.abs(pred-actual)/actual<=.15)hits++;total++;double err=Math.log(Math.max(1,actual))-y;double clip=Math.max(-1,Math.min(1,err));for(int j=0;j<ww.length;j++)ww[j]+=.018*clip*f[j]/(1+Math.abs(f[j]));}return total==0?0:100.0*hits/total;}
        void reset(){for(int i=0;i<w.length;i++)w[i]=new double[]{.35,1,-.2,.25,.08,-.3}[i];seen=0;save();}
    }

    class ChartView extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); ArrayList<Double>d=new ArrayList<Double>();
        ChartView(Context c){super(c);p.setStrokeWidth(dp(2));setBackground(round(Color.rgb(13,18,28),dp(14)));}
        void setData(ArrayList<Double>x){d=new ArrayList<Double>(x);invalidate();}
        protected void onDraw(Canvas c){super.onDraw(c);if(d.size()<2)return;float w=getWidth(),h=getHeight();int n=Math.min(80,d.size());double min=Double.MAX_VALUE,max=0;for(int i=d.size()-n;i<d.size();i++){min=Math.min(min,d.get(i));max=Math.max(max,d.get(i));}max=Math.max(max,min+1);p.setColor(Color.rgb(55,65,81));p.setStrokeWidth(1);for(int i=1;i<5;i++)c.drawLine(0,h*i/5f,w,h*i/5f,p);p.setColor(Color.rgb(81,255,190));p.setStrokeWidth(dp(2));float px=0,py=0;for(int j=0;j<n;j++){double v=d.get(d.size()-n+j);float x=w*j/(float)(n-1);float y=(float)(h-18-(v-min)/(max-min)*(h-30));if(j>0)c.drawLine(px,py,x,y,p);px=x;py=y;}p.setColor(Color.WHITE);p.setTextSize(dp(10));c.drawText(String.format(Locale.US,"max %.2fx",max),dp(8),dp(15),p);c.drawText(String.format(Locale.US,"min %.2fx",min),dp(8),h-dp(6),p);}
    }
}
