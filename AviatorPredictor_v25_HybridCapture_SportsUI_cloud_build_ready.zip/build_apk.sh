#!/bin/sh
# Gradle-less APK build. Run from a project root containing:
#   AndroidManifest.xml (package + versionCode + versionName), src/,
#   and optionally res/ and assets/.
set -e
P="${TOOLCHAIN:?run setup.sh first, then set TOOLCHAIN}"
AJ="$P/lib/android.jar"
OUT="${1:-app-debug.apk}"
MIN_SDK="${MIN_SDK:-24}"
TARGET_SDK="${TARGET_SDK:-35}"
KS="${KS:-$P/debug.keystore}"

# No /dev/null anywhere: the sandbox denies access to it.
[ -f AndroidManifest.xml ] || { echo "FATAL: AndroidManifest.xml missing"; exit 1; }
[ -d src ] || { echo "FATAL: src/ missing"; exit 1; }
case "$OUT" in *.apk) ;; *) echo "FATAL: output must end in .apk"; exit 1 ;; esac
[ ! -d "$OUT" ] || { echo "FATAL: output path is a directory: $OUT"; exit 1; }

rm -rf build
rm -f "$OUT"
mkdir -p build/gen build/classes build/dex

RES_ARG=""
if [ -d res ]; then
  echo "[1/7] aapt2 compile"
  "$P/bin/aapt2" compile --dir res -o build/res.zip
  RES_ARG="build/res.zip"
else
  echo "[1/7] aapt2 compile - no res/, skipping"
fi

ASSETS_ARG=""
[ -d assets ] && ASSETS_ARG="-A assets"

echo "[2/7] aapt2 link"
# build/res.zip is POSITIONAL. Via -R it is treated as an overlay and fails
# with "resource ... does not override an existing resource".
"$P/bin/aapt2" link -o build/base.apk -I "$AJ" \
  --manifest AndroidManifest.xml $RES_ARG --java build/gen $ASSETS_ARG \
  --min-sdk-version "$MIN_SDK" --target-sdk-version "$TARGET_SDK"

echo "[3/7] ecj (this box has a JRE, no javac)"
# -source/-target, NOT --release: --release needs lib/ct.sym which ships only
# with a JDK and dies here with "No provider for uri jar:...ct.sym".
# -bootclasspath is also rejected at compliance level >= 9.
java -cp "$P/lib/ecj" org.eclipse.jdt.internal.compiler.batch.Main \
  -source 8 -target 8 -nowarn -bootclasspath "$AJ" -classpath "$AJ" \
  -d build/classes $(find src build/gen -name '*.java')

echo "[4/7] d8"
java -cp "$P/lib/d8" com.android.tools.r8.D8 --lib "$AJ" \
  --min-api "$MIN_SDK" --output build/dex $(find build/classes -name '*.class')

echo "[5/7] pack dex"
(cd build/dex && zip -q -u ../base.apk classes.dex)

echo "[6/7] zipalign"
LD_LIBRARY_PATH="$P/lib64" "$P/bin/zipalign" -p -f 4 build/base.apk build/aligned.apk

echo "[7/7] apksigner"
# Opens /dev/random + /dev/urandom but tolerates EACCES - verified to produce a
# valid v2/v3 signature with both blocked. Keystore is pre-made, so keytool
# (which would need entropy) is never invoked.
java -cp "$P/lib/apksigner" com.android.apksigner.ApkSignerTool sign \
  --ks "$KS" --ks-pass pass:android --key-pass pass:android \
  --out "$OUT" build/aligned.apk

java -cp "$P/lib/apksigner" com.android.apksigner.ApkSignerTool verify -v "$OUT" \
  > build/apksigner-verify.txt
head -4 build/apksigner-verify.txt
ls -lh "$OUT"
