# Aviator AI Live Analyzer v23 — OCR row clustering

This revision keeps the v22 rendered-WebView frame capture and bundled Google ML Kit Latin recognizer, but fixes a key OCR assumption: ML Kit does not always return a horizontal multiplier history strip as one text line.

## OCR changes
- Collects OCR lines and their bounding boxes.
- Clusters text lines with nearby vertical centers, then orders each cluster from left to right.
- Extracts multiplier-like values from a whole visual row, allowing ML Kit to split each value into a separate line/block.
- Requires at least three plausible values and at least one visible `x`/`×` marker before treating a cluster as a completed-round history row.
- Normalizes accepted values to `valuex` before the existing overlap/deduplication history logic.
- Shows the OCR text, row decision, and history diagnostic in the data-quality panel.

## Build
Requires JDK 17, Android SDK platform 35, build-tools 35.0.0, and Gradle 8.9. Run `./build_ocr_apk.sh`. The generated APK is `dist/AviatorAI_LiveAnalyzer_v22_MLKit_OCR.apk` (legacy filename retained for compatibility).

## Important test limits
Source-level checks do not prove OCR accuracy. Install the APK and test with the real game history visible: confirm frame counts rise, recognized text includes the displayed values, a history row is detected, new values are added once, and unchanged frames do not add duplicates. If the game changes layout, OCR row grouping may need tuning.

Aviator-style crash-game outcomes are random and cannot be reliably predicted from previous multipliers. The app's estimates are descriptive statistics, not guaranteed next-round results.
